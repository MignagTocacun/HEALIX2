let selectedVoice = null;

// Function to list available voices
function getVoices() {
    let voices = window.speechSynthesis.getVoices();
    if (voices.length === 0) {
        setTimeout(getVoices, 100); // Retry if voices aren't available yet
        return;
    }

    // Loop through voices to find a female voice
    for (let i = 0; i < voices.length; i++) {
        if (voices[i].lang === "en-US" && voices[i].name.toLowerCase().includes("female")) {
            selectedVoice = voices[i];  // Explicitly picking a female voice
            break;
        }
    }

    // If no female voice found, fall back to the first available voice
    if (!selectedVoice) {
        selectedVoice = voices[0];
    }
}

// Initialize the voices when available
window.speechSynthesis.onvoiceschanged = getVoices;
getVoices();  // Ensure we retrieve voices immediately

// Function to speak with the selected voice (Baymax-like tone)
function speak(message) {
    if (!selectedVoice) {
        speak("I'm sorry, I couldn't find the right voice. Please wait.");
        return;
    }

    const speech = new SpeechSynthesisUtterance(message);
    speech.voice = selectedVoice;
    speech.volume = 1;
    speech.rate = 0.9;  // Slower, more friendly tone
    speech.pitch = 1.5; // Higher pitch for a soothing, approachable voice
    speech.lang = 'en-US';
    window.speechSynthesis.speak(speech);
}

// Function to introduce Healix (Baymax-like introduction)
function introduction() {
    speak("Hello, I am your healthcare companion, Healix. How may I assist you today?");
}

// Call the introduction when the page loads
window.onload = function() {
    introduction();
};

// Function to check health and provide tailored advice
function checkHealth() {
    let heartRate = document.getElementById('heartRate').value;
    let temperature = document.getElementById('temperature').value;
    let breathingRate = document.getElementById('breathingRate').value;

    let fever = document.getElementById('fever').checked;
    let cough = document.getElementById('cough').checked;
    let headache = document.getElementById('headache').checked;
    let fatigue = document.getElementById('fatigue').checked;
    let shortBreath = document.getElementById('shortBreath').checked;

    let healthCondition = "";
    let advice = "";

    // Separate Health Scanning & Diagnostics
    if (temperature && heartRate && breathingRate) {
        if (temperature > 38) {
            healthCondition = "You have a fever.";
            advice = "You should drink plenty of water and rest in a cool environment. You can take over-the-counter fever reducers like Paracetamol or Ibuprofen. Avoid cold showers, and keep monitoring your temperature every few hours. If the fever persists for more than 3 days or exceeds 39°C, consult a doctor.";
        } else if (heartRate > 100) {
            healthCondition = "Your heart rate is higher than normal.";
            advice = "Try to relax and avoid physical exertion. Stay hydrated and rest. If your heart rate remains above 100 bpm after resting for 30 minutes, consider taking Beta-blockers as prescribed or consult a doctor to rule out any underlying heart conditions.";
        } else if (breathingRate > 20) {
            healthCondition = "Your breathing rate is higher than normal.";
            advice = "Take slow, deep breaths to calm your respiratory rate. Avoid physical exertion and rest. If you experience dizziness, chest tightness, or shortness of breath, seek medical attention immediately.";
        } else {
            healthCondition = "Your vitals seem normal.";
            advice = "Your heart rate, temperature, and breathing are within the normal range. Keep following healthy habits such as staying hydrated, eating nutritious foods, and exercising regularly.";
        }
        speak(healthCondition + " " + advice);
    }

    // Separate Symptoms Check
    if (fever) {
        healthCondition = "You have a fever.";
        advice = "Drink plenty of fluids like water, herbal teas, and broths. You can also take Paracetamol for fever reduction, but avoid high doses. Rest in a cool environment, and keep monitoring your symptoms. If the fever lasts more than 3 days or you experience chills, see a doctor.";
    }
    if (cough) {
        healthCondition = "You have a cough.";
        advice = "Drink warm fluids like ginger tea, honey lemon water, and avoid irritants like smoke. If you have a dry cough, you may want to try over-the-counter cough suppressants like Dextromethorphan. If your cough lasts more than a week, is accompanied by chest pain, or is getting worse, please visit a healthcare professional.";
    }
    if (headache) {
        healthCondition = "You have a headache.";
        advice = "Headaches can be caused by dehydration, stress, or lack of sleep. Drink water and take over-the-counter pain relievers like Ibuprofen or Acetaminophen. Try to rest in a dark, quiet room and avoid screen time. If your headache persists or is severe, seek medical attention.";
    }
    if (fatigue) {
        healthCondition = "You feel fatigued.";
        advice = "Fatigue can result from stress, dehydration, or insufficient sleep. Ensure you're getting at least 7-9 hours of sleep each night and drinking enough water throughout the day. Consider reducing stress through relaxation techniques like meditation or yoga. If fatigue lasts more than a week or is accompanied by muscle weakness, consult a doctor.";
    }
    if (shortBreath) {
        healthCondition = "You have shortness of breath.";
        advice = "Stop any physical activity immediately and sit in a comfortable position. Take slow, deep breaths. If you experience tightness in the chest, dizziness, or rapid breathing, call for emergency help or go to the nearest ER.";
    }

    // Update text dynamically
    document.getElementById('condition').innerText = healthCondition;
    document.getElementById('advice').innerText = advice;

    // Speak the health condition and advice
    speak(healthCondition + " " + advice);
}
